<?php Skrollr_Footer_Menu::get_instance()->display(); ?>

<a id="bas-de-page"></a>
