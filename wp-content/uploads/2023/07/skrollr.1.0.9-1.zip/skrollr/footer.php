	<footer class="container-fluid">
		<?php Skrollr_Metadata::get_instance()->pagination(); ?>
	</footer>
